<?php
    $total = 0;
?>
;
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>      
        <div class="mb-5"> 
            <div class="float-start"> 
                <h5 class="card-title">Kirimlar Tarixi </h5> 
            </div> 
            <p></p> 
            <button type="button"  class="btn btn-secondary float-end" data-bs-toggle="modal" data-bs-target="#modalfilter"><i class="bi bi-funnel"></i></button> 
        </div> 
            <input type="text" class="form-control"  name="karobka" id="myInput" onkeyup="searchtable('myInput','myTable')" placeholder="Qidirish"> 
        <table class="table table-hover" id="myTable">
            <thead>
                <tr>
                    <thead>
                        <th>#</th>
                        <th>Inson</th>
                        <th>Sana</th>
                        <th>Summa</th>
                        <th>Izoh</th>
                    </thead>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($loop->index + 1); ?>

                            </td>
                            <td>
                                <?php echo e($item->custom->name); ?>

                            </td>
                            <td>
                                <?php echo e($item->date); ?>

                            </td>
                            <td>
                                <?php echo e(number_format($item->sum)); ?>

                            </td>
                            <?php
                                $total = $total + $item->sum;
                            ?>
                            <td>
                                <?php echo e($item->comment); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
               <tr>
                    <th>#</th>
                    <th>Inson</th>
                    <th>Sana</th>
                    <th><?php echo e(number_format($total)); ?></th>
                    <th>Izoh</th>
               </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<div class="modal fade" id="modalfilter" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('admin.operation.incomes')); ?>" method="get">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel2">Filtrlash</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row mb-3">
                <div class="col-sm-12">
                    <select class="form-select"  name="custom_id">
                        <option value="">Insonni Tanlash</option>
                        <?php $__currentLoopData = $staffes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($staff->id); ?>"><?php echo e($staff->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <p></p>
            <div class="row mb-3">
                <div class="input-group flex-nowrap">
                    <span class="input-group-text" id="addon-wrapping">Sanadan</span>
                    <input type="date" class="form-control" aria-label="Username" aria-describedby="addon-wrapping" name="from">
                </div>
                <p></p>
                <div class="input-group flex-nowrap">
                    <span class="input-group-text" id="addon-wrapping">Sanagacha</span>
                    <input type="date" class="form-control" aria-label="Username" aria-describedby="addon-wrapping" name="to">
                </div>
            </div>
            <br>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
            <button type="submit" class="btn btn-primary">Tanlash</button>
        </div>
    </div>
    </form>
    </div>
</div>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanelold\domains\paqir\resources\views/operation/incomes.blade.php ENDPATH**/ ?>