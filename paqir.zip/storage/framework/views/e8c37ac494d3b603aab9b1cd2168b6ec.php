<?php
    $total = 0;
    $totalspecial = 0;
?>
;
<?php $__env->startSection('content'); ?>
<section class="section dashboard">
    <div class="row">
        <div class="col-lg-8">
            <div class="row">
              <div class="col-12">
                <div class="card top-selling overflow-auto">
  
                  <div class="card-body pb-0">
                    <h5 class="card-title">Hisob Kitoblar <span>Kunlik</span></h5>
  
                    <table class="table table-borderless">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Inson</th>
                          <th scope="col">Summa</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td colspan="3">
                                  <b><?php echo e($loop->index+1); ?>: <?php echo e($item->name); ?></b>
                              </td>  
                          </tr>
                          <?php
                              $totalspecial = 0;
                          ?>
                          <?php $__currentLoopData = $item->staffes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td>
                                    <b><?php echo e($loop->index+1); ?></b>
                                  </td>
                                  <td>
                                    <?php echo e($staff->name); ?>

                                  </td>
                                  <td>
                                    <?php echo e(number_format($staff->balance)); ?>

                                  </td>
                              </tr>
                              <?php
                                  $totalspecial = $totalspecial + $staff->balance;
                              ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                              <?php
                                  $total = $total + $totalspecial;
                              ?> 
                            <tr>
                                <td colspan="3">
                                    <b>Jami: <?php echo e(number_format($totalspecial)); ?></b>
                                </td>  
                            </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="3">
                                <b>Umumiy: <?php echo e(number_format($total)); ?></b>
                            </td>  
                        </tr> 
                      </tbody>
                    </table>
  
                  </div>
  
                </div>
              </div>
              </div>
          </div>
        </div><!-- End Left side columns -->
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanelold\domains\paqir\resources\views/dashboard.blade.php ENDPATH**/ ?>