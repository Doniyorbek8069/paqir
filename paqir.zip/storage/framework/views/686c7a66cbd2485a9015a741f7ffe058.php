<?php
    $total = 0;
?>
;
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>      
        <div class="mb-5"> 
            <div class="float-start"> 
                <h5 class="card-title">Insonlar</h5> 
            </div> 
            <p></p> 
            <button type="button"  class="btn btn-success float-end" data-bs-toggle="modal" data-bs-target="#modalstore"><i class="bi bi-plus-square-dotted"></i></button> 
            <button type="button"  class="btn btn-secondary float-end" data-bs-toggle="modal" data-bs-target="#modalfilter"><i class="bi bi-funnel"></i></button> 
        </div> 
            <input type="text" class="form-control"  name="karobka" id="myInput" onkeyup="searchtable('myInput','myTable')" placeholder="Qidirish"> 
        <table class="table table-hover" id="myTable">
            <thead>
                <tr>
                    <th scope="col" class="align-middle">#</th>
                    <th scope="col" class="align-middle">Nomi</th>
                    <th scope="col" class="align-middle">Toifasi</th>
                    <th scope="col" class="align-middle">Balans</th>
                    <th scope="col" class="align-middle">Amallar</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $staffes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($staff->type_id); ?>">
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($staff->name); ?></td>
                        <td><?php echo e($staff->type->name); ?></td>
                        <td><?php echo e(number_format($staff->balance)); ?></td>
                        <?php
                            $total = $total + $staff->balance;
                        ?>
                        <td>
                            <button type="button"  class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal<?php echo e($loop->index); ?>"><i class="bi bi-pencil"></i></button> 
                            <div class="modal fade" id="modal<?php echo e($loop->index); ?>" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                <form action="<?php echo e(route('admin.staff.update', ['staff' => $staff->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel2">Tahrirlash</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" placeholder="Nomini Kiriting" name="name" value="<?php echo e($staff->name); ?>" required>
                                            </div>
                                        </div>
                                        <p></p>
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" placeholder="Telegram Chat Id" name="tg_chat_id" value="<?php echo e($staff->tg_chat_id); ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <select class="form-select" name="type_id" required>
                                                <option value="">Toifani tanlash</option>
                                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type->id); ?>" <?php if($type->id == $staff->type_id): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                                                        <?php echo e($type->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
                                    <button type="submit" class="btn btn-primary">Saqlash</button>
                                    </div>
                                </div>
                                </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th scope="col" class="align-middle">#</th>
                    <th scope="col" class="align-middle">Nomi</th>
                    <th scope="col" class="align-middle">Toifasi</th>
                    <th scope="col" class="align-middle"><?php echo e(number_format($total)); ?></th>
                    <th scope="col" class="align-middle">Amallar</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<div class="modal fade" id="modalstore" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('admin.staff.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel2">Hudud Qo'shish</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <div class="col-sm-12">
                    <input type="text" class="form-control" placeholder="Ismni Kiriting" name="name"  required>
                </div>
            </div>
            <p></p>
            <div class="row mb-3">
                <div class="col-sm-12">
                    <input type="number" class="form-control" placeholder="Qarzdorlik" name="balance"  required>
                </div>
            </div>
            <p></p>
            <div class="row mb-3">
                <div class="col-sm-12">
                    <input type="text" class="form-control" placeholder="Telegram Chat Id" name="tg_chat_id"  >
                </div>
            </div>
            <div class="col-sm-12">
                <select class="form-select" name="type_id" required>
                    <option value="">Inson Toifasini</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>">
                            <?php echo e($type->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
        <button type="submit" class="btn btn-primary">Saqlash</button>
        </div>
    </div>
    </form>
    </div>
</div>


<div class="modal fade" id="modalfilter" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('admin.staff.index')); ?>" method="get">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel2">Filtrlash</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row mb-3">
                <div class="col-sm-12">
                    <select class="form-select"  name="type_id">
                        <option value="">Toifani Tanlash</option>
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
            <button type="submit" class="btn btn-primary">Tanlash</button>
        </div>
    </div>
    </form>
    </div>
</div>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanelold\domains\paqir\resources\views/people/index.blade.php ENDPATH**/ ?>