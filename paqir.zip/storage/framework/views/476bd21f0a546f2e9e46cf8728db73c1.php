  <!-- Vendor JS Files -->
<script src="<?php echo e(asset('./backend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('./backend/assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('./backend/assets/js/main.js')); ?>"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js'></script>
<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH C:\OSPanelold\domains\paqir\resources\views/layouts/script.blade.php ENDPATH**/ ?>