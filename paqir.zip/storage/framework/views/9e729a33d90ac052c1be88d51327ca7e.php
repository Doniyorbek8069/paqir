<?php
    $total = 0;
?>
;
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>      
        <div class="mb-5"> 
            <div class="float-start"> 
                <h5 class="card-title"><?php echo e($staff->name); ?></h5> 
            </div> 
            <p></p> 
        </div> 
            <input type="text" class="form-control"  name="karobka" id="myInput" onkeyup="searchtable('myInput','myTable')" placeholder="Qidirish"> 
        <table class="table table-hover" id="myTable">
            <thead>
                <tr>
                    <th scope="col" class="align-middle">#</th>
                    <th scope="col" class="align-middle">Sana</th>
                    <th scope="col" class="align-middle">Kirim</th>
                    <th scope="col" class="align-middle">Chiqim</th>
                    <th scope="col" class="align-middle">Turi</th>
                    <th scope="col" class="align-middle">Qarzdorlik</th>
                    <th scope="col" class="align-middle">Izoh</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($item->date); ?></td>
                        <td><?php echo e(number_format($item->input)); ?></td>
                        <td><?php echo e(number_format($item->output)); ?></td>
                        <td>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($type['id'] == $item->type): ?>
                                    <b><?php echo e($type['name']); ?></b> 
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e(number_format($item->debt)); ?></td>
                       
                        <td>
                            <?php echo e($item->comment); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th scope="col" class="align-middle">#</th>
                    <th scope="col" class="align-middle">Nomi</th>
                    <th scope="col" class="align-middle">Toifasi</th>
                    <th scope="col" class="align-middle"><?php echo e(number_format($total)); ?></th>
                    <th scope="col" class="align-middle">Kirim Qilish</th>
                    <th scope="col" class="align-middle">Chiqim Qilish</th>
                    <th scope="col" class="align-middle">Tarix</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanelold\domains\paqir\resources\views/operation/history.blade.php ENDPATH**/ ?>