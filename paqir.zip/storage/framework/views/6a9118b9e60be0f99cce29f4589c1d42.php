<?php
    $total = 0;
?>
;
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>      
        <div class="mb-5"> 
            <div class="float-start"> 
                <h5 class="card-title">Insonlar</h5> 
            </div> 
            <p></p> 
            <button type="button"  class="btn btn-secondary float-end" data-bs-toggle="modal" data-bs-target="#modalfilter"><i class="bi bi-funnel"></i></button> 
        </div> 
            <input type="text" class="form-control"  name="karobka" id="myInput" onkeyup="searchtable('myInput','myTable')" placeholder="Qidirish"> 
        <table class="table table-hover" id="myTable">
            <thead>
                <tr>
                    <th scope="col" class="align-middle">#</th>
                    <th scope="col" class="align-middle">Nomi</th>
                    <th scope="col" class="align-middle">Toifasi</th>
                    <th scope="col" class="align-middle">Balans</th>
                    <th scope="col" class="align-middle">Kirim Qilish</th>
                    <th scope="col" class="align-middle">Chiqim Qilish</th>
                    <th scope="col" class="align-middle">Tarix</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $staffes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($staff->type_id); ?>">
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($staff->name); ?></td>
                        <td><?php echo e($staff->type->name); ?></td>
                        <td><?php echo e(number_format($staff->balance)); ?></td>
                        <?php
                            $total = $total + $staff->balance;
                        ?>
                        <td>
                            <button type="button"  data-bs-toggle="modal" data-bs-target="#modal<?php echo e($loop->index); ?>"class="btn btn-success" ><i class="bi bi-arrow-down-square"></i></button> 
                            <div class="modal fade" id="modal<?php echo e($loop->index); ?>" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                <form action="<?php echo e(route('admin.operation.income', ['staff' => $staff->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel2"><b><?php echo e($staff->name); ?>dan Kirim Qilish</b></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo csrf_field(); ?>
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <input type="numeric" class="form-control" placeholder="Summani Kiriting"  name="sum" required>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" placeholder="Izoh"  name="comment">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
                                    <button type="submit" class="btn btn-primary">Saqlash</button>
                                    </div>
                                </div>
                                </form>
                                </div>
                            </div>
                        </td>

                        <td>
                            <button type="button"  class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal1<?php echo e($loop->index); ?>"><i class="bi bi-arrow-up-square"></i></button> 
                            <div class="modal fade" id="modal1<?php echo e($loop->index); ?>" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                <form action="<?php echo e(route('admin.operation.outcome', ['staff' => $staff->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel2"><b><?php echo e($staff->name); ?>ga Chiqim Qilish</b></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <?php echo csrf_field(); ?>
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <input type="numeric" class="form-control" placeholder="Summani Kiriting" name="sum" required>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" placeholder="Izoh"  name="comment">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
                                    <button type="submit" class="btn btn-primary">Saqlash</button>
                                    </div>
                                </div>
                                </form>
                                </div>
                            </div>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.operation.history',['staff'=>$staff])); ?>" class="btn btn-success"><i class="bi bi-list-task"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th scope="col" class="align-middle">#</th>
                    <th scope="col" class="align-middle">Nomi</th>
                    <th scope="col" class="align-middle">Toifasi</th>
                    <th scope="col" class="align-middle"><?php echo e(number_format($total)); ?></th>
                    <th scope="col" class="align-middle">Kirim Qilish</th>
                    <th scope="col" class="align-middle">Chiqim Qilish</th>
                    <th scope="col" class="align-middle">Tarix</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<div class="modal fade" id="modalfilter" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('admin.operation.index')); ?>" method="get">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel2">Filtrlash</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="row mb-3">
                <div class="col-sm-12">
                    <select class="form-select"  name="type_id">
                        <option value="">Toifani Tanlash</option>
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
            <button type="submit" class="btn btn-primary">Tanlash</button>
        </div>
    </div>
    </form>
    </div>
</div>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanelold\domains\paqir\resources\views/operation/index.blade.php ENDPATH**/ ?>